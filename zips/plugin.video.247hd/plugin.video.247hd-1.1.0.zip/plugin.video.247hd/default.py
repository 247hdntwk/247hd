import urllib.request
import urllib.parse
import urllib.error
import re
import os
import base64
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

addon_id = 'plugin.video.247hd'
artpath = xbmc.translatePath(os.path.join(
    'special://home/addons/' + addon_id + '/resources/'))
xmlpath = xbmc.translatePath(os.path.join(
    'special://home/addons/' + addon_id + '/addon.xml'))
from resources import self
final = base64.b64decode
ADDON = xbmcaddon.Addon(id=final(b"cGx1Z2luLnZpZGVvLjI0N2hk").decode('utf-8'))
selfAddon = xbmcaddon.Addon(id=addon_id)
prettyName = final(b'MjQ3SEQ=').decode('utf-8')
fanart = xbmc.translatePath(os.path.join(
    'special://home/addons/' + addon_id, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(
    'special://home/addons/' + addon_id, 'icon.jpg'))
art = xbmc.translatePath(os.path.join(final(
    b'c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby4yNDdoZC9yZXNvdXJjZXMvYXJ0').decode('utf-8'), ''))
datapath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
UpdatePath = os.path.join(datapath, 'Update')
cookiedir = os.path.join(os.path.join(datapath, 'Cookies'))
cookie_file = os.path.join(os.path.join(datapath, 'Cookies'), '247hd.cookies')

logfile = open(xmlpath, 'r').read()


def hidegui():
    cookieExpired = False
    if os.path.exists(cookie_file):
        try:
            import time
            import datetime
            cookie = open(cookie_file).read()
            matches = re.finditer('(?i)expires="(.*?)"', cookie)
            for expire in matches:
                if expire:
                    expire = str(expire.group(1))
                    if time.time() > time.mktime(time.strptime(expire, '%Y-%m-%d %H:%M:%SZ')):
                        cookieExpired = True
            if time.mktime(datetime.date.yesterday().timetuple()) > os.stat(cookie_file).st_mtime:
                cookieExpired = True
        except:
            cookieExpired = True

        


def clearlink(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x":
            return chr(int(text[3:-1], 16))
        else:
            return chr(int(text[2:-1]))
    if type(text) is str:
        return re.sub("(?i)&#\w+;", fixup, text)
    else:
        return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))





def Set(id=addon_id):
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % id)


def Fresh():
    xbmc.executebuiltin("XBMC.Container.Refresh")


def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(500)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass


def clearCookies():
    dialog = xbmcgui.Dialog()
    if dialog.yesno('247HD', 'Are you sure you want to clear Cookies?', 'No', 'Yes'):
        import os
        cookie_file = os.path.join(datapath, 'Cookies')
        Clearfolder(xbmc.translatePath(cookie_file), True)
        xbmc.executebuiltin(
            "XBMC.Notification(Clear Cookies,Successful,5000,"")")


def Clearfolder(dir, clearNested=False):
    for the_file in os.listdir(dir):
        file_path = os.path.join(dir, the_file)
        if clearNested and os.path.isdir(file_path):
            Clearfolder(file_path, clearNested)
            try:
                os.rmdir(file_path)
            except Exception as e:
                print(str(e))
        else:
            try:
                os.unlink(file_path)
            except Exception as e:
                print(str(e))