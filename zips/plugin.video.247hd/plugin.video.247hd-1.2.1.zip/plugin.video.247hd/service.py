import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import os, urllib.request, urllib.parse, urllib.error, urllib.request, urllib.error, urllib.parse, re, threading
import time

ADDON = xbmcaddon.Addon(id='plugin.video.247hd')
sys.path.append(xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), 'resources')))

slogo = xbmcvfs.translatePath('special://home/addons/plugin.video.247hd/icon.png')

VERSION = str(ADDON.getAddonInfo('version')).replace('.','')

datapath = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
UpdatePath=os.path.join(datapath,'Update')
try: os.makedirs(UpdatePath)
except: pass

def OPENURL(url, mobile = False, q = False, verbose = True, timeout = 10, cookie = None, data = None, cookiejar = False, log = True, headers = [], type = '',ua = False):
    import urllib.request, urllib.error, urllib.parse 
    UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    if ua: UserAgent = ua
    try:

        if cookie and not cookiejar:
            import http.cookiejar
            cookie_file = os.path.join(os.path.join(datapath,'Cookies'), cookie+'.cookies')
            cj = http.cookiejar.LWPCookieJar()
            if os.path.exists(cookie_file):
                try: cj.load(cookie_file,True)
                except: cj.save(cookie_file,True)
            else: cj.save(cookie_file,True)
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        elif cookiejar:
            import http.cookiejar
            cj = http.cookiejar.LWPCookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        else:
            opener = urllib.request.build_opener()
        if mobile:
            opener.addheaders = [('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')]
        else:
            opener.addheaders = [('User-Agent', UserAgent)]
        for header in headers:
            opener.addheaders.append(header)
        if data:
            if type == 'json': 
                import json
                data = json.dumps(data)
                opener.addheaders.append(('Content-Type', 'application/json'))
            else: data = urllib.parse.urlencode(data)
            response = opener.open(url, data, timeout)
        else:
            response = opener.open(url, timeout=timeout)
        if cookie and not cookiejar:
            cj.save(cookie_file,True)
        link=response.read()
        response.close()
        opener.close()
        link=link.replace('&#39;',"'").replace('&quot;','"').replace('&amp;',"&").replace("&#39;","'").replace('&lt;i&gt;','').replace("#8211;","-").replace('&lt;/i&gt;','').replace("&#8217;","'").replace('&amp;quot;','"').replace('&#215;','x').replace('&#038;','&').replace('&#8216;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','').replace('&#8212;','')
        link=link.replace('%3A',':').replace('%2F','/')
        if q: q.put(link)
        return link
    except Exception as e:
        if verbose:
            xbmc.executebuiltin("XBMC.Notification(Sorry!,Source Website is Down,3000,"+slogo+")")
        xbmc.log('***********Website Error: '+str(e)+'**************', xbmc.LOGERROR)
        import traceback
        traceback.print_exc()
        link ='website down'
        if q: q.put(link)
        return link

def setFile(path,content,force=False):
    if os.path.exists(path) and not force:
        return False
    else:
        try:
            open(path,'w+').write(content)
            return True
        except: pass
    return False


def CheckForAutoUpdate(force = False):
    UpdateVerFile = 'update'
    RunningFile   = 'running'
    verCheck=False 
    if verCheck == True:
        import autoupdate
        import time
        try:
            print("247HD auto update - started")
            html=OPENURL('http://kodi.247hd.tv/version', mobile=True, verbose=False)
        except:
            html=''
        try:newver = int(re.findall('(?sim)\d+',html)[0])
        except: newver = 0        
        try: locver = int(VERSION)
        except: locver = 0
        RunningFilePath = os.path.join(UpdatePath, RunningFile)
        if locver < newver and (not os.path.exists(RunningFilePath) or os.stat(RunningFilePath).st_mtime + 120 < time.time()) or force:
            UpdateUrl = 'http://kodi.247hd.tv/plugin.video.247hd.zip'
            UpdateLocalName = '247hd.zip'
            UpdateLocalFile = xbmcvfs.translatePath(os.path.join(UpdatePath, UpdateLocalName))
            setFile(RunningFilePath,'')
            print("auto update - new update available ("+str(newver)+")")
            xbmc.executebuiltin("XBMC.Notification(247HD Update,New Update detected,3000,"+slogo+")")
            xbmc.executebuiltin("XBMC.Notification(247HD Update,Updating...,3000,"+slogo+")")
            try:os.remove(UpdateLocalFile)
            except:pass
            try: urllib.request.urlretrieve(UpdateUrl,UpdateLocalFile)
            except:pass
            if os.path.isfile(UpdateLocalFile):
                extractFolder = xbmcvfs.translatePath('special://home/addons')
                pluginsrc =  xbmcvfs.translatePath(os.path.join(extractFolder,'plugin.video.247hd'))
                if autoupdate.unzipAndMove(UpdateLocalFile,extractFolder,False):
                    print("247HD auto update - update install successful ("+str(newver)+")")
                    xbmc.executebuiltin("XBMC.Notification(247HD Update,Successful,5000,"+slogo+")")
                    xbmc.executebuiltin("XBMC.Container.Refresh")

                else:
                    print("247HD auto update - update install failed ("+str(newver)+")")
                    xbmc.executebuiltin("XBMC.Notification(247HD Update,Failed,3000,"+slogo+")")

            else:
                print("247HD auto update - cannot find downloaded update ("+str(newver)+")")
                xbmc.executebuiltin("XBMC.Notification(247HD Update,Failed,3000,"+slogo+")")
            try:os.remove(RunningFilePath)
            except:pass
        else:
            if force: xbmc.executebuiltin("XBMC.Notification(247HD Update,HQZone is up-to-date,3000,"+slogo+")")
            print("247HD auto update - HQZone is up-to-date ("+str(locver)+")")
        return   


        



CheckForAutoUpdate()
