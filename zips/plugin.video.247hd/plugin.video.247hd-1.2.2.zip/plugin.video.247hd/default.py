import urllib.request, urllib.parse, urllib.error, re, http.cookiejar, string, os, random, time, datetime
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, xbmcvfs
from bs4 import BeautifulSoup

addon_id = 'plugin.video.247hd'
artpath = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/'))
xmlpath = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id + '/addon.xml'))
ADDON=xbmcaddon.Addon(id='plugin.video.247hd')
selfAddon = xbmcaddon.Addon(id=addon_id)
prettyName='247HD'
fanart= xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon= xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id , 'icon.jpg'))
art = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.247hd/resources/art', ''))
datapath = xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
UpdatePath=os.path.join(datapath,'Update')
cookiedir = os.path.join(os.path.join(datapath,'Cookies'))
cookie_file = os.path.join(os.path.join(datapath,'Cookies'), '247hd.cookies')

logfile = open(xmlpath, 'r').read()
match=re.findall('name="247HD.tv" version="(.+?)"',logfile)
if match:
    for n in match:
        VERSION = n.replace('.','')
try: os.makedirs(UpdatePath)
except: pass

try: os.makedirs(cookiedir)
except: pass


def OPENURL(url, mobile = False, q = False, verbose = True, timeout = 10, cookie = None, data = None,
            cookiejar = False, log = True, headers = [], types = '',ua = False,setCookie = [],raiseErrors = False,ignore_discard = True):
    import urllib.request, urllib.error, urllib.parse 
    UserAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36'
    if ua: UserAgent = ua
    try:
        if log:
            xbmc.log("Openurl = " + url, xbmc.LOGINFO)
        if cookie and not cookiejar:
            import http.cookiejar
            cookie_file = os.path.join(os.path.join(datapath,'Cookies'), cookie+'.cookies')
            cj = http.cookiejar.LWPCookieJar()
            if os.path.exists(cookie_file):
                try:
                    cj.load(cookie_file,ignore_discard)
                    for c in setCookie:
                        cj.set_cookie(c)
                except: cj.save(cookie_file,True)
            else: cj.save(cookie_file,True)
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        elif cookiejar:
            import http.cookiejar
            cj = http.cookiejar.LWPCookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
        else:
            opener = urllib.request.build_opener()
        if mobile:
            opener.addheaders = [('User-Agent', 'Mozilla/6.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/8.0 Mobile/10A5376e Safari/8536.25')]
        else:
            opener.addheaders = [('User-Agent', UserAgent)]
        for header in headers:
            opener.addheaders.append(header)
        if data:
            if types == 'json': 
                import json
                data = str.encode(json.dumps(data))
                opener.addheaders.append(('Content-Type', 'application/json'))
            else: data = str.encode((urllib.parse.urlencode(data)))
        
        response = opener.open(url, data, timeout)
        if cookie and not cookiejar:
            cj.save(cookie_file,ignore_discard)
        opener.close()
        link=response.read()
        if type(link) is bytes:
            link=link.decode('utf-8', 'ignore')
        response.close()
        link=link.replace('&#39;',"'").replace('&quot;','"').replace('&amp;',"&").replace("&#39;","'").replace('&lt;i&gt;','').replace("#8211;","-").replace('&lt;/i&gt;','').replace("&#8217;","'").replace('&amp;quot;','"').replace('&#215;','x').replace('&#038;','&').replace('&#8216;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','').replace('&#8212;','')
        link=link.replace('%3A',':').replace('%2F','/')
        if q: q.put(link)
        return link
    except Exception as e:
        if raiseErrors: raise
        if verbose:
            from urllib.parse import urlparse
            try:
                host = urlparse(url).hostname.replace('www.','').partition('.')[0]
            except:
                host = ''
            xbmc.executebuiltin("XBMC.Notification(Sorry!,"+host.title()+" Website is Down,3000,"+icon+")")
        xbmc.log('***********Website Error: '+str(e)+'**************', xbmc.LOGERROR)
        xbmc.log('***********Url: '+url+' **************', xbmc.LOGERROR)
        import traceback
        traceback.print_exc()
        link ='website down'
        if q: q.put(link)
        return link


def setFile(path,content,force=False):
    if os.path.exists(path) and not force:
        return False
    else:
        try:
            open(path,'w+').write(content)
            return True
        except: pass
    return False

def loginDialog():
    if os.path.exists(cookie_file):
        try:
            os.remove(cookie_file)
        except Exception as e:
            xbmc.log('Error while removing cookie file %s : %s' % (cookie_file, e), xbmc.LOGINFO)
            pass
    dialog = xbmcgui.Dialog()
    ret = dialog.yesno('[COLOR red]247HD[/COLOR]', 'Please set your 247HD credentials or register if you dont have an account at 247HD.tv','Cancel','Login')
    if ret == 1:
        keyb = xbmc.Keyboard('', 'Enter Username')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            username=search
            keyb = xbmc.Keyboard('', 'Enter Password:')
            keyb.setHiddenInput(True)
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText()
                password=search
                selfAddon.setSetting('247username',username)
                selfAddon.setSetting('247password',password)

user = selfAddon.getSetting('247username')
passw = selfAddon.getSetting('247password')
if user == '' or passw == '':
    loginDialog()
    
user = selfAddon.getSetting('247username')
passw = selfAddon.getSetting('247password')

def CheckForAutoUpdate(force = False):
    slogo = xbmcvfs.translatePath('special://home/addons/plugin.video.247hd/icon.png')
    UpdateVerFile = 'update'
    RunningFile   = 'running'
    verCheck=False 
    if verCheck == True:
        import autoupdate
        import time
        try:
            print("247HD auto update - started")
            html=OPENURL('http://kodi.247hd.tv/version', mobile=True, verbose=False)
        except:
            html=''
        try:newver = int(re.findall('(?sim)\d+',html)[0])
        except: newver = 0        
        try: locver = int(VERSION)
        except: locver = 0
        RunningFilePath = os.path.join(UpdatePath, RunningFile)
        if locver < newver and (not os.path.exists(RunningFilePath) or os.stat(RunningFilePath).st_mtime + 120 < time.time()) or force:
            UpdateUrl = 'http://kodi.247hd.tv/plugin.video.247hd.zip'
            UpdateLocalName = '247hd.zip'
            UpdateLocalFile = xbmcvfs.translatePath(os.path.join(UpdatePath, UpdateLocalName))
            setFile(RunningFilePath,'')
            print("auto update - new update available ("+str(newver)+")")
            xbmc.executebuiltin("XBMC.Notification(247HD Update,New Update detected,3000,"+slogo+")")
            xbmc.executebuiltin("XBMC.Notification(247HD Update,Updating...,3000,"+slogo+")")
            try:os.remove(UpdateLocalFile)
            except:pass
            try: urllib.request.urlretrieve(UpdateUrl,UpdateLocalFile)
            except:pass
            if os.path.isfile(UpdateLocalFile):
                extractFolder = xbmcvfs.translatePath('special://home/addons')
                pluginsrc =  xbmcvfs.translatePath(os.path.join(extractFolder,'plugin.video.247hd'))
                if autoupdate.unzipAndMove(UpdateLocalFile,extractFolder,False):
                    print("247HD auto update - update install successful ("+str(newver)+")")
                    xbmc.executebuiltin("XBMC.Notification(247HD Update,Successful,5000,"+slogo+")")
                    xbmc.executebuiltin("XBMC.Container.Refresh")

                else:
                    print("247HD auto update - update install failed ("+str(newver)+")")
                    xbmc.executebuiltin("XBMC.Notification(247HD Update,Failed,3000,"+slogo+")")

            else:
                print("247HD auto update - cannot find downloaded update ("+str(newver)+")")
                xbmc.executebuiltin("XBMC.Notification(247HD Update,Failed,3000,"+slogo+")")
            try:os.remove(RunningFilePath)
            except:pass
        else:
            if force: xbmc.executebuiltin("XBMC.Notification(247HD Update,247HD is up-to-date,3000,"+slogo+")")
            print("247HD auto update - 247HD is up-to-date ("+str(locver)+")")
        return   

def isLogged():
    if user == '' or passw == '':
        return False
    link = OPENURL('https://www.247hd.tv/forums/view.php?pg=webtemplate#',cookie='247hd')
    idx = link.find(user)
    if user in link:
        return True
    else:
        return False

def setCookie():
    cookieExpired = False
    if os.path.exists(cookie_file):
        try:
            import time,datetime
            cookie = open(cookie_file).read()
            matches = re.finditer('(?i)expires="(.*?)"',cookie)
            for expire in matches:
                if expire:
                    expire = str(expire.group(1))
                    if time.time() > time.mktime(time.strptime(expire, '%Y-%m-%d %H:%M:%SZ')):
                       cookieExpired = True
            yesterday = datetime.date.today() - datetime.timedelta(days = 1)
            if time.mktime(yesterday.timetuple()) > os.stat(cookie_file).st_mtime:
               cookieExpired = True
        except Exception as e:
            xbmc.log('Error while setting cookie : %s' % (e), xbmc.LOGINFO)
            cookieExpired = True
    loggedin = isLogged()
    if not os.path.exists(cookie_file) or cookieExpired or (not loggedin and user != '' and passw != ''):
        data = {}
        data['vb_login_username'] = user
        data['vb_login_password'] = passw
        data['Referer'] = 'https://www.247hd.tv/forums/view.php?pg=webtemplate#'

        import hashlib
        m = hashlib.md5()
        m.update(str.encode(passw))
        md5= m.hexdigest()
        data['vb_login_md5password'] = md5
        data['vb_login_md5password_utf'] = md5
        data['s'] = ''
        data['securitytoken'] = 'guest'
        data['cookieuser'] = '1'
        data['do'] = 'login'
        OPENURL('https://www.247hd.tv/forums/login.php?do=login',data=data,cookie='247hd')
           
def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return chr(int(text[3:-1], 16))
        else: return chr(int(text[2:-1]))
    if type(text) is str:
        return re.sub("(?i)&#\w+;", fixup, text)
    else:
        return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))

def MAINSA():
    import datetime
    date=datetime.date.today()
    setCookie()
    urllist=[]
    namelist=[]
    link = OPENURL('https://www.247hd.tv/forums/view.php?pg=webtemplate#',cookie='247hd')
    link2 = OPENURL('https://www.247hd.tv/forums/calendar.php?do=getinfo&day='+str(date)+'&c=1',cookie='247hd')
    link = cleanHex(link)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
    link2 = cleanHex(link2)
    link2=link2.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
    loggedin = isLogged()
    if loggedin:
        matchlist=re.compile('<ul class="inner-ul">(.+?)</ul></a>').findall(link)
        for urls in matchlist:
            urllist.append(urls)
        addLink('[COLOR red][I]VIP Member[/I][/COLOR]',artpath+'empty.png','')
        addLink2('[I][COLOR red]Refresh Links[/COLOR][/I]  (Click Here if Videos are not playing)','url',555,artpath+'empty.png',fanart)
        addDir('[COLOR blue]All Channels[/COLOR] (Click Here)','test',477,artpath+'channels.png')
        addDir('[COLOR blue]VOD[/COLOR] (Click Here)','https://www.247hd.tv/forums/view.php?pg=cbvod#',478,artpath+'vod.png')
        addDir('[COLOR blue]Schedule[/COLOR] (Click Here)','test',476,artpath+'schedule.png')
        
        match=re.compile('<span class="time">([^<]+)</span> to <span class="time">([^<]+)</span>.+?<h2 class="title">([^<]+)</h2>').findall(link2)	 
        for time1,time2,title in match:
            try:ch=re.findall('(?sim)channel\s(\d+)',title)[0]
            except:ch=re.findall('(?sim)Channel\s(\d+)',title)[0]
            title = re.sub("(Channel \d+)","",title)
            num=int(ch)-1
            addPlay('[COLOR ffde251d]'+time1+' - '+time2+'[/COLOR] '+title +' [COLOR orange]Channel: '+str(ch)+'[/COLOR]',urllist[num],411,art+ch+'.png')
      
	 	
    else:
        addLink('Login Failed : try again','','')
        addLink2('[B][COLOR red]Login[/B][/COLOR]','url',358,artpath+'empty.png',fanart)
                
    if loggedin:
	    addLink(' ','','')
	    addLink('[B][COLOR blue]Twitter[/B][/COLOR] [COLOR white]@Plus1HD[/COLOR]','',artpath+'empty.png')
	    addLink2('[COLOR grey][I]For support visit https://www.247hd.tv/forums/forum.php[/I][/COLOR]','url','',artpath+'empty.png',fanart)
	
def FullChannel(murls):
    setCookie()
    i=1
    link = OPENURL('https://www.247hd.tv/forums/view.php?pg=webtemplate#',cookie='247hd')
    link = cleanHex(link)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')    
    addLink2('[I][COLOR red]Refresh Links[/COLOR][/I]  (Click Here if Videos are not playing)','url',555,artpath+'empty.png',fanart)
    if isLogged():
        matchlist=re.compile('<li>([^<]+)</li><ul class="inner-ul">(.+?)</ul></a>').findall(link)
        for name,urls in matchlist:
            addPlay(name,urls,411,art+str(i)+'.png')
            i=i+1
        
def VOD(murl):    
    if 'https://www.247hd.tv/forums/view.php?pg=cbvod#' in murl:
        setCookie()
        if isLogged():
            link = OPENURL(murl,cookie='247hd')
            link = cleanHex(link)
            link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
            match=re.compile('<li>([^<]+)</li><ul class="inner-ul">(.+?)</ul></a>').findall(link)
            for name,urls in match:
                addDir(name,urls,478,'')
    else:
        match=re.compile('<a href="(.+?)" target=".+?">(.+?)</a>').findall(murl)
        for url,name in match:
            url='https://www.247hd.tv/forums/'+url
            addPlay(name,url,413,'')
            
def Set(id=addon_id):
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % id)

def Fresh():
	xbmc.executebuiltin("XBMC.Container.Refresh")
	
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(500)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass

def Login():
    if user == '' or passw == '':
        loginDialog()
    setCookie()
    xbmcgui.Dialog().ok('Restart', 'Kodi will stop. Please start again Kodi')
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin('ActivateWindow(ShutdownMenu)')

def ClearDir(dir, clearNested = False):
    for the_file in os.listdir(dir):
        file_path = os.path.join(dir, the_file)
        if clearNested and os.path.isdir(file_path):
            ClearDir(file_path, clearNested)
            try:
                os.rmdir(file_path)
            except Exception as e:
                xbmc.log('Remove directory failed : %s' % (e), xbmc.LOGINFO)
        else:
            try:
                os.unlink(file_path)
            except Exception as e:
                xbmc.log('Remove file failed : %s' % (e), xbmc.LOGINFO)

def Calendar(murl, addday = 0):
    import time, datetime
    import xml.etree.ElementTree as ET
    setCookie()
    if not isLogged():
        return
        
    urllist=[]
    data = {}
    data['category'] = 0
    try:
        allowedtz = ['America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Asia/Hong_Kong', 'MST']
        # First try to get timezone from add-on setting
        timezone = selfAddon.getSetting('247timezone')
        if timezone in allowedtz:
            # OK, use the one in the add-on setting
            data['timezone'] = timezone
        else:
            # Try to get timezone from system setting (initialized by Kodi at startup)
            guisettings = xbmcvfs.translatePath(os.path.join('special://home/userdata/guisettings.xml'))
            root = ET.parse(guisettings).getroot()
            res = root.findall(".//*[@id='locale.timezone']")
            if len(res) > 0 and res[0].text in allowedtz:
                # OK, use the one from system setting
                data['timezone'] = res[0].text
            else:
                # Use default value
                data['timezone'] = "America/New_York"
                xbmc.log('Error while getting Kodi timezone => use default value', xbmc.LOGERROR)
    except Exception as e:
        # Use default value
        data['timezone'] = "America/New_York"
        xbmc.log('Error while getting Kodi timezone : %s' % (e), xbmc.LOGERROR)
    now = datetime.datetime.now()
    if now.hour >= 6:
        begin = datetime.datetime(now.year, now.month, now.day, 6, 0, 0)
    else:
        yesterday = now - datetime.timedelta(days = 1)
        begin = datetime.datetime(yesterday.year, yesterday.month, yesterday.day, 6, 0, 0)
    if addday > 0:
        begin = begin + datetime.timedelta(days = addday)
    data['day'] = int(begin.timestamp())
    link  = OPENURL('https://www.247hd.tv/schedule/index_data.php',data=data,cookie='247hd')
    link2 = OPENURL('https://www.247hd.tv/forums/view.php?pg=webtemplate#',cookie='247hd')
    link = cleanHex(link)
    link2=link2.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
    soup = BeautifulSoup(link, "html.parser")
    trs = soup.find_all('tr')
    for tr in trs:
        day = ''
        title = ''
        channel = ''
        tds = tr.find_all('td')
        if len(tds) > 0:
            day = tds[0].text
        if len(tds) > 3:
            channel = tds[3].text
        if len(tds) > 4:
            title = tds[4].text
        if day != '' and title != '' and channel != '':
            addPlay('[COLOR ffde251d]'+day+'[/COLOR] ' + title + ' (channel ' + channel + ')', channel, 411, art + channel + '.png')

    while addday < 2:
        addday = addday + 1
        Calendar(murl, addday)


def LISTCONTENT(murl,thumb):
    if not isLogged():
        return
    urllist=[]
    namelist=[]
    match=re.compile('<li><a href="([^"]+)".+?arget=".+?">([^<]+)</a></li>').findall(murl)
    for url, name in match:
        urllist.append('https://www.247hd.tv/forums/'+url)
        namelist.append(name)   
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select Source',namelist)
    if ret == -1:
        return
    else:
        ans=urllist[ret]
        PLAYLINK(namelist[ret],ans,'')
				

def get_link(murl):
    setCookie()
    link  = OPENURL(murl,cookie='247hd')
    link = cleanHex(link)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
    m3u8=re.findall("""'file': "([^"]+?)",""",link)
    m3u8B=m3u8B=re.findall(".*{source: '(.*.m3u8.*)'",link)
    iframe=re.findall('<iframe src="(https://admin.livestreamingcdn.com[^"]+?)"',link)
    if m3u8:
        return m3u8[0]
    elif 'https://www.247hd.tv/forums/view.php?pg' in murl:
        swf=re.findall('src="([^<]+).swf"',link)[0]
        file=re.findall("file=(.+?)&",link)[0] 
        file=file.replace('.flv','')
        streamer=re.findall("streamer=(.+?)&",link)[0]
        if '.mp4' in file and 'vod' in streamer:
            file='mp4:'+file
            return streamer.replace('redirect','live')+' playpath='+file+' swfUrl='+swf+'.swf pageUrl='+murl
        else:
            return streamer.replace('redirect','live')+' playpath='+file+' swfUrl='+swf+'.swf pageUrl='+murl+' live=true timeout=20'
    elif m3u8B:
        return m3u8B[0].split("'")[0]
    elif 'euplayer' or 'usplayer' in murl:
        vlink=re.findall("""'file': "([^"]+)",""",link)
        return vlink[0]
    elif iframe:
        with urlopen(iframe[0]) as response:
            link = response.read()
            link = cleanHex(link)
            link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
            vlink=re.findall('file: "([^"]+?.m3u8)"',link)
            return vlink[0]
    
    else:
        swf=re.findall("src='([^<]+).swf'",link)[0]
        file=re.findall("file=(.+?)&",link)[0] 
        file=file.replace('.flv','')
        streamer=re.findall("streamer=(.+?)&",link)[0]
        if '.mp4' in file and 'vod' in streamer:
            file='mp4:'+file
            return streamer.replace('redirect','live')+' playpath='+file+' swfUrl='+swf+'.swf pageUrl='+murl
        else:
            return streamer.replace('redirect','live')+' playpath='+file+' swfUrl='+swf+'.swf pageUrl='+murl+' live=true timeout=20'
    
def PLAYLINK(mname,murl,thumb):
        ok=True
        stream_url = get_link(murl)     
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        listitem = xbmcgui.ListItem(mname)
        listitem.setArt({'thumb': thumb})
        playlist.add(stream_url,listitem)
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playlist)
        return ok  
                

def addPlay(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage=" + urllib.parse.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({'icon': '', 'thumb': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image',fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz, isFolder = False)
        return ok

def addLink2(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage="+urllib.parse.quote_plus(iconimage)+"&fanart="+urllib.parse.quote_plus(fanart)+"&description="+urllib.parse.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok	
		
def addLink(name,url,iconimage):
    liz=xbmcgui.ListItem(name)
    liz.setArt({'icon': art+'/empty.png', 'thumb': iconimage})
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image',fanart)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def addDir2(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
	
def addDir(name, url, mode, iconimage):

        u  = sys.argv[0]

        u += "?url="  + urllib.parse.quote_plus(url)
        u += "&mode=" + str(mode)
        u += "&name=" + urllib.parse.quote_plus(name)
        u += "&iconimage=" + urllib.parse.quote_plus(iconimage)

        liz = xbmcgui.ListItem(name)
        liz.setArt({'icon': '', 'thumb': iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image',fanart)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=True)
	

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
              
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
    iconimage=urllib.parse.unquote_plus(params["iconimage"])
    iconimage = iconimage.replace(' ','%20')
except:
        pass

print("Mode: "+str(mode))
print("Name: "+str(name))
print("Thumb: "+str(iconimage))

if mode==None or url==None:
        import threading
        threading.Thread(target=CheckForAutoUpdate).start()
        MAINSA()
        
    
        
elif mode==411:LISTCONTENT(url,iconimage)
elif mode==413:PLAYLINK(name,url,iconimage)
elif mode==476:Calendar(url)
elif mode==477:FullChannel(url)
elif mode==478:VOD(url)
elif mode==358:Login()
elif mode==239:Set()
elif mode==555:Fresh()
elif mode==240:
    if selfAddon.getSetting("server-location") == "true":
        selfAddon.setSetting('server-location', 'false')
        print('false')
    else:
        selfAddon.setSetting('server-location', 'true')
        print('true')
    xbmc.executebuiltin("XBMC.Container.Refresh")

xbmcplugin.endOfDirectory(int(sys.argv[1]))
